244755 Szymon Głąb

Program został napisany w Pythonie w wersji 3.7.4. Wszystkie kody źródłowe znajdują się w pliku l6.py oraz stats.py.

Program został przygotowany w wersji na ocenę 3

Uruchomienie programu:

    python3 l6.py <OPCJA> <INPUT> <OUTPUT> <K>
    python3 stats.py <PLIK1> <PLIK2>

    <OPCJA> -'encode' lub 'decode'








