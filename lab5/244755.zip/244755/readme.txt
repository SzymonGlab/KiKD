244755 Szymon Głąb

Program został napisany w Pythonie w wersji 3.7.4. Wszystkie kody źródłowe znajdują się w pliku l5.py.

Program został przygotowany w wersji na ocenę 3

Uruchomienie programu:
    python3 l5.py <INPUT> <OUTPUT> <RB> <GB> <BB>

    <INPUT> - plik wejściowy
    <OUTPUT> - plik wyjściowy
    <RB> - liczba pikseli na kolor czerwony
    <GB> - liczba pikseli na kolor zielony
    <BB> - liczba pikseli na kolor niebieski




