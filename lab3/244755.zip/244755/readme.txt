244755 Szymon Głąb

Program został napisany w Pythonie w wersji 3.7.4. Wszystkie kody źródłowe znajdują się w pliku l3.py.

Program koduje <plik wejściowy> przy pomocy wybranego kodowania. Alfabetem wejściowym dla programu są 8-bitowe kody ASCII.

Progoram posiada opcje kodowania oraz dekodowania:

    1. kodowanie ------> python3 l3.py -o/-g/-d/-fibb encode <plik wejściowy> <plik wyjściowy>
    2. dekodowanie ----> python3 l3.py -o/-g/-d/-fibb decode <plik wejściowy> <plik wyjściowy>

Opcje odpowiednio odpowiadają:
    -o - kodowanie Eliasa omega
    -g - kodowanie Eliasa gamma
    -d - kodowanie Eliasa delta
    -fibb - kodowanie Fibbonaciego




