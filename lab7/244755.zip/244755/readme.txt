244755 Szymon Głąb

Program został napisany w Pythonie w wersji 3.7.4. Programy zostały nazwane tak jak zostało zasugerowane na liście.

Przygotowano 4 programy:

- koder.py
- dekoder.py
- szum.py
- sprawdz.py

Uruchomienie programu:

    python3 koder.py <INPUT> <OUTPUT> 
    python3 szum.py <INPUT> <OUTPUT> <K>
    python3 dekoder.py <INPUT> <OUTPUT> 
    python3 sprawdz.py <INPUT1> <INPUT2>









