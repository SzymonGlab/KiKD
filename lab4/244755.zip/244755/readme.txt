244755 Szymon Głąb

Program został napisany w Pythonie w wersji 3.7.4. Wszystkie kody źródłowe znajdują się w pliku l4.py.

Program wczytuje nazwę pliku (python3 l4.py <nazwa_pliku>), następnie wyświetla wymagane informacje.




